package com.example.techanalysis.domain

import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class DerivException(message: String) : Exception(message)

/**
 * Cotations Deriv via l'API WebSocket officielle.
 * Les données de marché ne demandent aucun jeton : seul l'app_id est requis (1089 = identifiant public de test).
 */
class DerivQuoteProvider(
    private val appId: String = "1089",
    private val endpoint: String = "wss://ws.binaryws.com/websockets/v3",
    private val client: OkHttpClient = OkHttpClient(),
) : QuoteProvider {

    private fun wsRequest() = Request.Builder().url("$endpoint?app_id=$appId").build()

    private fun granularity(tf: Timeframe) = when (tf) {
        Timeframe.M1 -> 60
        Timeframe.M5 -> 300
        Timeframe.M15 -> 900
        Timeframe.H1 -> 3600
        Timeframe.D1 -> 86400
    }

    private fun candlesBody(symbol: String, tf: Timeframe, count: Int, subscribe: Boolean) = JSONObject()
        .put("ticks_history", symbol)
        .put("adjust_start_time", 1)
        .put("count", count)
        .put("end", "latest")
        .put("style", "candles")
        .put("granularity", granularity(tf))
        .apply { if (subscribe) put("subscribe", 1) }
        .toString()

    private fun errorOf(j: JSONObject): String? = j.optJSONObject("error")?.optString("message")

    /** Envoie une requête, attend la réponse contenant [key], puis ferme la connexion. */
    private suspend fun oneShot(request: String, key: String): JSONObject =
        withTimeout(15_000) {
            suspendCancellableCoroutine<JSONObject> { cont ->
                val ws = client.newWebSocket(wsRequest(), object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) { webSocket.send(request) }

                    override fun onMessage(webSocket: WebSocket, text: String) {
                        val j = JSONObject(text)
                        val err = errorOf(j)
                        if (err != null) {
                            if (cont.isActive) cont.resumeWithException(DerivException(err))
                            webSocket.close(1000, null)
                            return
                        }
                        if (!j.has(key)) return
                        if (cont.isActive) cont.resume(j)
                        webSocket.close(1000, null)
                    }

                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        if (cont.isActive) cont.resumeWithException(t)
                    }
                })
                cont.invokeOnCancellation { ws.cancel() }
            }
        }

    override suspend fun history(symbol: String, timeframe: Timeframe, count: Int): List<Candle> {
        val arr = oneShot(candlesBody(symbol, timeframe, count, false), "candles").getJSONArray("candles")
        return (0 until arr.length()).map { i ->
            val c = arr.getJSONObject(i)
            Candle(c.getLong("epoch"), c.getDouble("open"), c.getDouble("high"), c.getDouble("low"), c.getDouble("close"))
        }
    }

    override suspend fun symbols(): List<SymbolInfo> {
        val req = JSONObject().put("active_symbols", "brief").put("product_type", "basic").toString()
        val arr = oneShot(req, "active_symbols").getJSONArray("active_symbols")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val s = o.getString("symbol")
            SymbolInfo(s, o.optString("display_name", s), o.optString("market_display_name", o.optString("market", "Autres")))
        }.sortedBy { it.name }
    }

    override fun stream(symbol: String, timeframe: Timeframe): Flow<Candle> = callbackFlow {
        val ws = client.newWebSocket(wsRequest(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(candlesBody(symbol, timeframe, 1, subscribe = true))
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val j = JSONObject(text)
                errorOf(j)?.let { close(DerivException(it)); return }
                j.optJSONObject("ohlc")?.let { o ->
                    trySend(Candle(o.getLong("open_time"), o.getDouble("open"), o.getDouble("high"), o.getDouble("low"), o.getDouble("close")))
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { close(t) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { close() }
        })
        awaitClose { ws.cancel() }
    }
}
