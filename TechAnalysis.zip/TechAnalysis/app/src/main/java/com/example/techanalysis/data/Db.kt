package com.example.techanalysis.data

import android.content.Context
import androidx.room.*
import com.example.techanalysis.domain.Candle
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "candles", primaryKeys = ["symbolKey", "timeframe", "time"])
data class CandleEntity(
    val symbolKey: String, val timeframe: String, val time: Long,
    val open: Double, val high: Double, val low: Double, val close: Double,
)

/** kind : "H" = ligne horizontale (support/résistance), "T" = ligne de tendance. */
@Entity(tableName = "drawings")
data class DrawingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val symbolKey: String, val timeframe: String, val kind: String,
    val t1: Long, val p1: Double, val t2: Long, val p2: Double,
)

@Dao
interface AppDao {
    @Query("SELECT * FROM candles WHERE symbolKey = :key AND timeframe = :tf ORDER BY time DESC LIMIT :n")
    suspend fun lastCandles(key: String, tf: String, n: Int): List<CandleEntity>

    @Upsert suspend fun upsertCandles(list: List<CandleEntity>)

    @Query("SELECT * FROM drawings WHERE symbolKey = :key AND timeframe = :tf")
    fun observeDrawings(key: String, tf: String): Flow<List<DrawingEntity>>

    @Insert suspend fun insertDrawing(d: DrawingEntity)
    @Query("DELETE FROM drawings WHERE id = :id") suspend fun deleteDrawing(id: Long)
    @Query("DELETE FROM drawings WHERE symbolKey = :key AND timeframe = :tf") suspend fun clearDrawings(key: String, tf: String)
}

@Database(entities = [CandleEntity::class, DrawingEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "techanalysis.db").build().also { inst = it }
        }
    }
}

fun CandleEntity.toCandle() = Candle(time, open, high, low, close)
fun Candle.toEntity(key: String, tf: String) = CandleEntity(key, tf, time, open, high, low, close)
