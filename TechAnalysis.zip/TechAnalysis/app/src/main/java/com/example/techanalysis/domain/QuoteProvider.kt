package com.example.techanalysis.domain

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import java.time.LocalDate
import java.time.ZoneOffset
import kotlin.math.abs
import kotlin.random.Random

enum class Timeframe { M1, M5, M15, H1, D1 }

data class SymbolInfo(val symbol: String, val name: String, val market: String)

/**
 * Point d'entrée unique pour les cotations.
 * L'étape « courtier » consistera à écrire une classe qui implémente cette interface.
 */
interface QuoteProvider {
    suspend fun history(symbol: String, timeframe: Timeframe, count: Int): List<Candle>
    /** Bougie en cours, mise à jour en temps réel (optionnel). */
    fun stream(symbol: String, timeframe: Timeframe): Flow<Candle> = emptyFlow()
    /** Instruments disponibles chez le courtier (liste vide si non supporté). */
    suspend fun symbols(): List<SymbolInfo> = emptyList()
}

/** Marche aléatoire reproductible pour développer sans connexion. */
class SampleQuoteProvider : QuoteProvider {
    override suspend fun history(symbol: String, timeframe: Timeframe, count: Int): List<Candle> {
        val rnd = Random(symbol.hashCode())
        var price = 100.0
        var day = LocalDate.now().minusDays(count * 7L / 5 + 2)
        val out = ArrayList<Candle>(count)
        while (out.size < count) {
            day = day.plusDays(1)
            if (day.dayOfWeek.value > 5) continue
            val open = price
            val close = open * (1 + (rnd.nextDouble() - 0.485) * 0.03)
            val high = maxOf(open, close) * (1 + abs(rnd.nextDouble()) * 0.01)
            val low = minOf(open, close) * (1 - abs(rnd.nextDouble()) * 0.01)
            out += Candle(day.atStartOfDay().toEpochSecond(ZoneOffset.UTC), open, high, low, close, 1_000 + rnd.nextDouble() * 5_000)
            price = close
        }
        return out
    }
}

/** Import CSV : date;open;high;low;close[;volume], date au format AAAA-MM-JJ, séparateur , ou ; */
object Csv {
    fun parse(text: String): List<Candle> {
        val rows = text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.mapNotNull { line ->
            val c = line.split(',', ';', '\t').map { it.trim() }
            if (c.size < 5) return@mapNotNull null
            val date = runCatching { LocalDate.parse(c[0].take(10)) }.getOrNull() ?: return@mapNotNull null
            fun num(i: Int) = c[i].replace(',', '.').toDouble()
            Candle(date.atStartOfDay().toEpochSecond(ZoneOffset.UTC), num(1), num(2), num(3), num(4), c.getOrNull(5)?.toDoubleOrNull() ?: 0.0)
        }.sortedBy { it.time }.toList()
        require(rows.size >= 30) { "Au moins 30 lignes valides sont nécessaires (format : date,open,high,low,close,volume)." }
        return rows
    }
}
